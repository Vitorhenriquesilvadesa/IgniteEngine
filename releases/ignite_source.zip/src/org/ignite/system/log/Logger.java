package org.ignite.system.log;

import static org.ignite.core.macros.Macros.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger {

    private int logLevel;
    private String color;
    private String resetColor = "\u001B[0m";
    private String name;

    private DateFormat dateFormat;

    private static boolean lineSeparator = false;

    public Logger(String name, int logLevel) {
        this.logLevel = logLevel;
        this.name = name;
    }

    public int getLogLevel() {
        return this.logLevel;
    }

    public void setLogLevel(int level) {
        this.logLevel = level;
    }

    public static void setLineSeparator(boolean value) {
        Logger.lineSeparator = value;
    }

    public void trace(Object target) {
        setColor(LogColor.WHITE);
        print("TRACE", target);
    }

    public void debug(Object target) {
        if (DEBUG) {
            setColor(LogColor.GREEN);
            print("DEBUG", target);
        }
    }

    public void info(Object target) {
        setColor(LogColor.BLUE);
        print("INFO", target);
    }

    public void warn(Object target) {
        setColor(LogColor.YELLOW);
        print("WARN", target);
    }

    public void error(Object target) {
        setColor(LogColor.MAGENTA);
        print("ERROR", target);
    }

    public void critical(Object target) {
        setColor(LogColor.RED);
        print("CRITICAL", target);
    }

    public void exception(Exception exception) {
        setColor(LogColor.RED);
        print("EXCEPTION", exception.getMessage() + ": " + exception.getStackTrace());
        System.exit(-1);
    }

    public void exception(Object exception) {
        setColor(LogColor.RED);
        print("EXCEPTION", exception.toString());
        System.exit(-1);
    }

    private void setColor(String color) {
        this.color = color;
    }

    private void print(String handle, Object target) {
        this.dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String formatedDate = this.dateFormat.format(date);

        String logtarget = this.color + formatedDate + " " + this.name + " [" + handle + "]: " + target.toString()
                + this.resetColor;

        if (Logger.lineSeparator) {
            StringBuilder line = new StringBuilder();

            for (int i = 0; i < logtarget.length(); i++) {
                line.append("_");
            }

            System.out.println(line + "\n");
        }

        System.out.println(logtarget);
    }
}
