package org.ignite.system.meta;

import java.lang.annotation.*;

/**
 * Specifies classes to compound Ignite Engine API
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE })
public @interface Define {

    String value();

}
