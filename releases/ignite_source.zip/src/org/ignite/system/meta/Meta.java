package org.ignite.system.meta;

import java.lang.annotation.Annotation;

public final class Meta {

    public static boolean check(String className, String annotation, String param) {

        try {
            Class<?> checker = Class.forName("com.vtko." + className);

            Annotation[] annotations = checker.getDeclaredAnnotations();

            for (Annotation a : annotations) {

                String annotationName = a.toString().replace("@com.vtko.meta.", "");

                if (annotationName.startsWith("Define")) {

                    String paramValue = (String) a.annotationType().getMethod("value").invoke(a);

                    if (paramValue.equals(param)) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {

            e.printStackTrace();
        }

        return false;
    }
}
