package org.ignite.platform.general;

import org.ignite.events.*;
import org.ignite.system.meta.Define;

@Define("IGNITE_API")
public interface Window {

    public abstract void onUpdate();

    public abstract int getWidth();

    public abstract int getHeight();

    public abstract void setEventCallback(EventCallbackFn<Event> callback);

    public abstract void setVSync(boolean enabled);

    public abstract boolean isVSync();

    public abstract long getNativeWindow();

    // public Window create(WindowProps props);

    // public Window create();
}
