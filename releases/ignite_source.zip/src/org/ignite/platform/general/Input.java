package org.ignite.platform.general;

import org.ignite.core.macros.Pair;

public abstract class Input {

    protected static Input instance;

    public static boolean isKeyPressed(int keycode) {
        return instance.isKeyPressedImpl(keycode);
    }

    public static boolean isMouseButtonPressed(int button) {
        return instance.isMouseButtonPressedImpl(button);
    }

    public static float getMouseX() {
        return instance.getMouseXImpl();
    }

    public static float getMouseY() {
        return instance.getMouseYImpl();
    }

    public static Pair<Float, Float> getMousePosition() {
        return instance.getMousePositionImpl();
    }

    protected abstract boolean isKeyPressedImpl(int keycode);

    protected abstract boolean isMouseButtonPressedImpl(int button);

    protected abstract float getMouseXImpl();

    protected abstract float getMouseYImpl();

    protected abstract Pair<Float, Float> getMousePositionImpl();
}
