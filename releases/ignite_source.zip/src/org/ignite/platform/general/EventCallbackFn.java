package org.ignite.platform.general;

import org.ignite.events.Event;
import org.ignite.system.meta.Define;

@Define("IGNITE_API")
@FunctionalInterface
public interface EventCallbackFn<T extends Event> {
    void apply(T target);
}
