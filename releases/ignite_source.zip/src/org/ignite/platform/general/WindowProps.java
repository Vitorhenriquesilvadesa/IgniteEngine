package org.ignite.platform.general;

import org.ignite.system.meta.Define;

@Define("IGNITE_API")
public class WindowProps {

    private String title;
    private int width;
    private int height;

    public WindowProps(String title, int width, int height) {
        this.title = title;
        this.width = width;
        this.height = height;
    }

    public WindowProps() {
        this.title = "Ignite Engine";
        this.width = 1280;
        this.height = 720;
    }

    public String getTitle() {
        return title;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public String toString() {
        return "WindowProps: " + this.title + "(" + this.width + ", " + this.height + ")";
    }
}
