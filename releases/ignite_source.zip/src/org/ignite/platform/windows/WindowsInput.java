package org.ignite.platform.windows;

import org.ignite.core.app.Application;
import org.ignite.core.macros.Pair;
import org.ignite.platform.general.Input;

import static org.lwjgl.glfw.GLFW.*;

public class WindowsInput extends Input {

    public static void init() {
        instance = new WindowsInput();
    }

    @Override
    protected boolean isKeyPressedImpl(int keycode) {

        long window = Application.getInstance().getWindow().getNativeWindow();
        int state = glfwGetKey(window, keycode);
        return state == GLFW_PRESS || state == GLFW_REPEAT;
    }

    @Override
    protected boolean isMouseButtonPressedImpl(int button) {
        long window = Application.getInstance().getWindow().getNativeWindow();
        int state = glfwGetMouseButton(window, button);
        return state == GLFW_PRESS;
    }

    @Override
    protected float getMouseXImpl() {
        long window = Application.getInstance().getWindow().getNativeWindow();
        double[] xPos = new double[1];
        double[] yPos = new double[1];

        glfwGetCursorPos(window, xPos, yPos);

        return (float) xPos[0];
    }

    @Override
    protected float getMouseYImpl() {
        long window = Application.getInstance().getWindow().getNativeWindow();
        double[] xPos = new double[1];
        double[] yPos = new double[1];

        glfwGetCursorPos(window, xPos, yPos);

        return (float) yPos[0];
    }

    @Override
    protected Pair<Float, Float> getMousePositionImpl() {
        long window = Application.getInstance().getWindow().getNativeWindow();
        double[] xPos = new double[1];
        double[] yPos = new double[1];

        glfwGetCursorPos(window, xPos, yPos);

        return new Pair<Float, Float>((float) xPos[0], (float) yPos[0]);
    }

}
