package org.ignite.core.macros;

public class BreakPoint {
    private String file;
    private int line;

    public BreakPoint(String file, int line) {
        this.file = file;
        this.line = line;
    }

    public String getFile() {
        return file;
    }

    public int getLine() {
        return line;
    }
}
