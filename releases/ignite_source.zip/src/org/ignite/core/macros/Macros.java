package org.ignite.core.macros;

import static org.ignite.core.app.Application.ClientLog;

public final class Macros {

    public static final boolean DEBUG = false;

    public static int _bit(int x) {
        return (int) 1 << x;
    }

    public static void _assert(String message, boolean... args) {
        for (boolean b : args) {
            if (!b) {
                ClientLog.exception(message);
            }
        }
    }

    public static BreakPoint _debugbreak() {
        if (DEBUG) {
            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            if (stackTrace.length > 2) {
                StackTraceElement element = stackTrace[2];
                String fileName = element.getFileName();
                int lineNumber = element.getLineNumber();
                ClientLog.trace("__debugbreak executed on file " + fileName + " on line " + lineNumber);
                System.exit(-1);
                return new BreakPoint(fileName, lineNumber);
            }
        }

        return null;
    }

    public static void _delete(Pointer<? extends Object> ref) {
        ref.setReference(null);
    }
}
