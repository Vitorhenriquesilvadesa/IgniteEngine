package org.ignite.core.macros;

public class Pair<T, F> {

    private T Tvalue;
    private F Fvalue;

    public Pair(T tvalue, F fvalue) {
        this.Tvalue = tvalue;
        this.Fvalue = fvalue;
    }

    public T getTvalue() {
        return Tvalue;
    }

    public void setTvalue(T tvalue) {
        Tvalue = tvalue;
    }

    public F getFvalue() {
        return Fvalue;
    }

    public void setFvalue(F fvalue) {
        Fvalue = fvalue;
    }
}
