package org.ignite.core.app;

import org.ignite.events.Event;
import org.ignite.events.EventDispatcher;
import org.ignite.events.EventType;
import org.ignite.events.KeyCode;
import org.ignite.events.WindowCloseEvent;
import org.ignite.layers.Layer;
import org.ignite.layers.LayerStack;
import org.ignite.platform.general.Window;
import org.ignite.platform.general.WindowProps;
import org.ignite.platform.windows.WindowsInput;
import org.ignite.platform.windows.WindowsWindow;
import org.ignite.system.log.LogLevel;
import org.ignite.system.log.Logger;
import org.ignite.system.meta.Define;

import static org.ignite.core.macros.Macros.*;
import static org.lwjgl.opengl.GL11.*;

@Define("IGNITE_API")
public abstract class Application {

    public static Logger ClientLog = new Logger("Ignite Engine", LogLevel.TRACE);
    private static boolean RUNNING = true;
    private Window window;
    private LayerStack layerStack = new LayerStack();
    protected static Application app;

    public Application() {
        this.window = WindowsWindow.create(new WindowProps());
        this.window.setEventCallback(this::onEvent);
    }

    public static void init() {
        ClientLog.trace("Application initialized.");

        WindowsInput.init();

        if (!System.getProperty("os.name").startsWith("Windows") || !System.getProperty("os.arch").contains("64")) {
            ClientLog.error("Ignite Engine only supports Windows x64");
            System.exit(-1);
        }
        if (DEBUG) {
            System.setProperty("DEBUG", "true");
        }

        Logger.setLineSeparator(true);
    }

    public void onEvent(Event e) {
        EventDispatcher dispatcher = new EventDispatcher(e);
        dispatcher.dispatch(EventType.WindowClose, this::onWindowClose);
        ClientLog.debug(e);

        for (int i = this.layerStack.size() - 1; i > 0; i--) {

            Layer layer = this.layerStack.get(i);
            layer.onEvent(e);
            if (e.isHandled()) {
                break;
            }
        }
    }

    public void run() {
        this.start();

        while (Application.RUNNING) {
            this.update();
            glClearColor(0, 0, 0, 1);
            glClear(GL_COLOR_BUFFER_BIT);

            for (Layer layer : this.layerStack) {
                layer.onUpdate();
            }

            if (WindowsInput.isKeyPressed(KeyCode.Tab)) {
                ClientLog.info("Tab is pressed");
            }

            this.window.onUpdate();
        }
    }

    public abstract void start();

    public abstract void update();

    public boolean onWindowClose(WindowCloseEvent e) {
        RUNNING = false;
        return true;
    }

    public void pushLayer(Layer layer) {
        this.layerStack.pushLayer(layer);
        layer.onAttach();
    }

    public void pushOverlay(Layer layer) {
        this.layerStack.pushOverlay(layer);
        layer.onAttach();
    }

    public Window getWindow() {
        return this.window;
    }

    public static Application getInstance() {
        return app;
    }

    public static void setInstance(Application app) {
        Application.app = app;
    }
}
