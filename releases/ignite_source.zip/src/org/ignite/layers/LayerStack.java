package org.ignite.layers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ignite.core.macros.*;
import static org.ignite.core.macros.Macros.*;

public class LayerStack implements Iterable<Layer> {

    private List<Layer> layers;

    public LayerStack() {
        this.layers = new ArrayList<Layer>();
    }

    public void pushLayer(Layer layer) {
        this.layers.add(0, layer);
    }

    public void pushOverlay(Layer overlay) {
        this.layers.add(overlay);
    }

    public void popLayer(Layer layer) {
        int index = this.layers.indexOf(layer);
        if (index != this.layers.size()) {
            this.layers.remove(layer);
        }
    }

    public void popOverlay(Layer overlay) {
        int index = this.layers.indexOf(overlay);
        if (index != this.layers.size()) {
            this.layers.remove(overlay);
        }
    }

    public Layer begin() {
        return this.layers.get(0);
    }

    public Layer end() {
        return this.layers.get(this.layers.size() - 1);
    }

    public int size() {
        return this.layers.size();
    }

    public Layer get(int index) {
        return this.layers.get(index);
    }

    public void clear() {
        for (Layer l : this.layers) {
            Pointer<Layer> ref = new RawPointer<Layer>(l);
            _delete(ref);
        }
    }

    @Override
    public Iterator<Layer> iterator() {
        return this.layers.iterator();
    }
}
