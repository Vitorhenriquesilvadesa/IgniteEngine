package org.ignite.layers;

import org.ignite.events.Event;
import org.ignite.system.meta.Define;

@Define("IGNITE_API")
public abstract class Layer {

    private String debugName;

    public Layer(String name) {
        this.debugName = name;
    }

    public Layer() {
        this.debugName = "Layer";
    }

    public abstract void onAttach();

    public abstract void onDettach();

    public abstract void onUpdate();

    public abstract void onEvent(Event e);

    public String getName() {
        return this.debugName;
    }

}
