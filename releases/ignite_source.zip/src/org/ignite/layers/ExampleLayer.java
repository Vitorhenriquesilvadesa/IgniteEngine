package org.ignite.layers;

import static org.ignite.core.app.Application.ClientLog;

import org.ignite.events.Event;

public class ExampleLayer extends Layer {

    @Override
    public void onAttach() {

    }

    @Override
    public void onDettach() {

    }

    @Override
    public void onUpdate() {
        ClientLog.debug("ExampleLayer::Update");
    }

    @Override
    public void onEvent(Event e) {
        ClientLog.trace(e);
    }

}
