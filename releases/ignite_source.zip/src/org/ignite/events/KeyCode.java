package org.ignite.events;

public final class KeyCode {
    public static final int Space = 32;
    public static final int Apostrophe = 39; /* ' */
    public static final int Comma = 44; /* , */
    public static final int Minus = 45; /* - */
    public static final int Period = 46; /* . */
    public static final int Slash = 47; /* / */

    public static final int D0 = 48; /* 0 */
    public static final int D1 = 49; /* 1 */
    public static final int D2 = 50; /* 2 */
    public static final int D3 = 51; /* 3 */
    public static final int D4 = 52; /* 4 */
    public static final int D5 = 53; /* 5 */
    public static final int D6 = 54; /* 6 */
    public static final int D7 = 55; /* 7 */
    public static final int D8 = 56; /* 8 */
    public static final int D9 = 57; /* 9 */

    public static final int Semicolon = 59; /* ; */
    public static final int Equal = 61; /* = */

    public static final int A = 65;
    public static final int B = 66;
    public static final int C = 67;
    public static final int D = 68;
    public static final int E = 69;
    public static final int F = 70;
    public static final int G = 71;
    public static final int H = 72;
    public static final int I = 73;
    public static final int J = 74;
    public static final int K = 75;
    public static final int L = 76;
    public static final int M = 77;
    public static final int N = 78;
    public static final int O = 79;
    public static final int P = 80;
    public static final int Q = 81;
    public static final int R = 82;
    public static final int S = 83;
    public static final int T = 84;
    public static final int U = 85;
    public static final int V = 86;
    public static final int W = 87;
    public static final int X = 88;
    public static final int Y = 89;
    public static final int Z = 90;

    public static final int LeftBracket = 91; /* [ */
    public static final int Backslash = 92; /* \ */
    public static final int RightBracket = 93; /* ] */
    public static final int GraveAccent = 96; /* ` */

    public static final int World1 = 161; /* non-US #1 */
    public static final int World2 = 162; /* non-US #2 */

    /* Function keys */
    public static final int Escape = 256;
    public static final int Enter = 257;
    public static final int Tab = 258;
    public static final int Backspace = 259;
    public static final int Insert = 260;
    public static final int Delete = 261;
    public static final int Right = 262;
    public static final int Left = 263;
    public static final int Down = 264;
    public static final int Up = 265;
    public static final int PageUp = 266;
    public static final int PageDown = 267;
    public static final int Home = 268;
    public static final int End = 269;
    public static final int CapsLock = 280;
    public static final int ScrollLock = 281;
    public static final int NumLock = 282;
    public static final int PrintScreen = 283;
    public static final int Pause = 284;
    public static final int F1 = 290;
    public static final int F2 = 291;
    public static final int F3 = 292;
    public static final int F4 = 293;
    public static final int F5 = 294;
    public static final int F6 = 295;
    public static final int F7 = 296;
    public static final int F8 = 297;
    public static final int F9 = 298;
    public static final int F10 = 299;
    public static final int F11 = 300;
    public static final int F12 = 301;
    public static final int F13 = 302;
    public static final int F14 = 303;
    public static final int F15 = 304;
    public static final int F16 = 305;
    public static final int F17 = 306;
    public static final int F18 = 307;
    public static final int F19 = 308;
    public static final int F20 = 309;
    public static final int F21 = 310;
    public static final int F22 = 311;
    public static final int F23 = 312;
    public static final int F24 = 313;
    public static final int F25 = 314;

    /* Keypad */
    public static final int KP0 = 320;
    public static final int KP1 = 321;
    public static final int KP2 = 322;
    public static final int KP3 = 323;
    public static final int KP4 = 324;
    public static final int KP5 = 325;
    public static final int KP6 = 326;
    public static final int KP7 = 327;
    public static final int KP8 = 328;
    public static final int KP9 = 329;
    public static final int KPDecimal = 330;
    public static final int KPDivide = 331;
    public static final int KPMultiply = 332;
    public static final int KPSubtract = 333;
    public static final int KPAdd = 334;
    public static final int KPEnter = 335;
    public static final int KPEqual = 336;

    public static final int LeftShift = 340;
    public static final int LeftControl = 341;
    public static final int LeftAlt = 342;
    public static final int LeftSuper = 343;
    public static final int RightShift = 344;
    public static final int RightControl = 345;
    public static final int RightAlt = 346;
    public static final int RightSuper = 347;
    public static final int Menu = 348;
}
