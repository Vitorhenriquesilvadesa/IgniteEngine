package org.sandbox;

import org.ignite.core.app.Application;
import org.ignite.layers.ExampleLayer;
import org.ignite.layers.imgui.ImGuiLayer;

public class Sandbox extends Application {

    public void start() {
        app.pushLayer(new ExampleLayer());
        app.pushOverlay(new ImGuiLayer(app));
    }

    public void update() {

    }
}
