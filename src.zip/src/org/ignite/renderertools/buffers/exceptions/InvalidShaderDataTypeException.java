package org.ignite.renderertools.buffers.exceptions;

public class InvalidShaderDataTypeException extends RuntimeException {

    public InvalidShaderDataTypeException() {

    }

    public InvalidShaderDataTypeException(String message) {
        super(message);
    }
}
