/**
 * Ignite Engine - A powerful game engine in Java.
 *
 * @license MIT License
 *
 * @author Creator: Lord Vtko
 * @version 1.0.0
 * @since 2023-07-28
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */

package org.ignite.system.functions;

public class Tick {

    protected Tick() {

    }

    public void call(boolean condition, GenericFunction caller) {

        if (condition) {
            caller.apply();
        }
    }
}
