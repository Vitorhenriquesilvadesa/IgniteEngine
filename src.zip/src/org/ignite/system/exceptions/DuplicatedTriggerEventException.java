package org.ignite.system.exceptions;

public class DuplicatedTriggerEventException extends RuntimeException {

    public DuplicatedTriggerEventException(String message) {
        super(message);
    }
}
