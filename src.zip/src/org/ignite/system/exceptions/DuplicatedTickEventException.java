package org.ignite.system.exceptions;

public class DuplicatedTickEventException extends RuntimeException {

    public DuplicatedTickEventException(String message) {
        super(message);
    }
}
