package org.ignite.system.exceptions;

public class InexistentTickEventException extends RuntimeException {

    public InexistentTickEventException(String message) {
        super(message);
    }
}
