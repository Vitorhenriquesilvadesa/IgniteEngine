package org.ignite.system.exceptions;

public class InexistentTriggerEventException extends RuntimeException {
    public InexistentTriggerEventException(String message) {
        super(message);
    }
}
