package org.ignite.layers.imgui;

public enum ImGuiThemes {
    OneDark,
    Dracula
}
