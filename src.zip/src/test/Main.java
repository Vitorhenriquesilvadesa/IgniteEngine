package test;

import org.ignite.core.app.Application;
import org.ignite.core.macros.memory.Pointer;
import org.ignite.core.macros.memory.RawPointer;

public class Main {
    public static void main(String[] args) {
        Application.init();
        Application.setInstance(Sandbox.class);
        Application.getInstance().run();
    }
}