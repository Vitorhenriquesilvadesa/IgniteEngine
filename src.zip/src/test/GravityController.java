package test;

import org.datum.iterables.tables.HashTable;
import org.datum.iterables.tables.Table;
import org.ignite.mathf.Vector3;

public class GravityController {

    //private Table<>
    public GravityController() {
    }
}
