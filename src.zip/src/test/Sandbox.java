package test;

import org.ignite.core.app.Application;
import org.ignite.core.macros.memory.Pointer;
import org.ignite.core.macros.memory.RawPointer;
import org.ignite.events.KeyCode;
import org.ignite.platform.general.Input;
import org.ignite.renderertools.buffers.general.BufferElement;
import org.ignite.renderertools.buffers.general.BufferLayout;
import org.ignite.renderertools.buffers.general.ShaderDataType;
import org.ignite.renderertools.renderer.Renderer;
import org.ignite.renderertools.shader.Shader;

import java.util.ArrayList;
import java.util.List;

public class Sandbox extends Application {

    private Shader shader;
    List<Particle> particles;

    public void start(){

        this.particles = new ArrayList<>();
        this.particles.add(new Particle());
        this.shader = new Shader("renderertools/shaders/vertex.shader",
                "renderertools/shaders/fragment.shader");

    }

    public void update(){

        Renderer.beginScene();

        this.shader.bind();

        for(Particle particle : particles){
            particle.render();
        }

        this.shader.unbind();

        Renderer.endScene();
    }
}