package test;

import org.ignite.core.macros.memory.SharedPointer;
import org.ignite.mathf.Vector3;
import org.ignite.renderertools.buffers.general.*;
import org.ignite.renderertools.renderer.Renderer;
import org.ignite.renderertools.shader.Shader;

import java.util.List;

public class Mesh {

    private List<Vector3> vertices;
    private SharedPointer<VertexArray> vertexArray;

    private SharedPointer<VertexBuffer> verticesBuffer;

    private SharedPointer<IndexBuffer> indexBuffer;

    private BufferLayout layout;

    private int count;

    public Mesh(List<Vector3> vertices, int[] indices){
        this.vertices = vertices;

        float[] verticesCoords = new float[vertices.size() * 3];

        for(int i = 0; i < vertices.size(); i++){
            verticesCoords[i * 3] = vertices.get(i).x;
            verticesCoords[i * 3 + 1] = vertices.get(i).y;
            verticesCoords[i * 3 + 2] = vertices.get(i).z;
            System.out.println(vertices.get(i).toString());
        }

        BufferLayout layout = new BufferLayout(
                new BufferElement(ShaderDataType.Float3, "a_Position"));

        this.verticesBuffer = new SharedPointer<>();
        this.verticesBuffer.reset(VertexBuffer.create(verticesCoords));
        this.vertexArray = new SharedPointer<>();
        this.vertexArray.reset(VertexArray.create());
        this.indexBuffer = new SharedPointer<>();
        this.indexBuffer.reset(IndexBuffer.create(indices));

        this.verticesBuffer.getReference().setLayout(layout);
        this.vertexArray.getReference().addVertexBuffer(this.verticesBuffer);
        this.vertexArray.getReference().setIndexBuffer(this.indexBuffer);

    }

    public void setVertices(List<Vector3> vertices){
        this.vertices = vertices;
    }

    public void render(){
        Renderer.submit(this.vertexArray);
    }
}
