package test;

import org.ignite.mathf.Vector3;
import org.ignite.renderertools.shader.Shader;

import java.util.ArrayList;
import java.util.List;

public class Particle {

    private Mesh mesh;

    public Particle(){

        List<Vector3> vertices = new ArrayList<>();

        for(int i = 0; i < 2; i++){
            for(int j = 0; j < 2; j++){
                vertices.add(new Vector3(i/4f + 0.5f, j/4f + 0.5f, 0));
            }
        }

        this.mesh = new Mesh(vertices, new int[] { 2, 1, 0, 0, 3, 2 });
    }

    public void render(){
        this.mesh.render();
    }
}
